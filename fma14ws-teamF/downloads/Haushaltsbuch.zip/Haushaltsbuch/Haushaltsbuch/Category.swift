//
//  Haushaltsbuch.swift
//  Haushaltsbuch
//
//  Created by Medien on 22.12.14.
//  Copyright (c) 2014 THM. All rights reserved.
//

import Foundation
import CoreData

class Category: NSManagedObject {

    @NSManaged var name: String
    @NSManaged var entry: NSSet
    @NSManaged var subcategory: NSSet

}
