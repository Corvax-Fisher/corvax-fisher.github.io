//
//  MainViewController.swift
//  Haushaltsbuch
//
//  Created by Medien on 08.12.14.
//  Copyright (c) 2014 THM. All rights reserved.
//

import UIKit
import CoreData

class MainViewController: UIViewController, NSFetchedResultsControllerDelegate, UITableViewDelegate, UITableViewDataSource {
    
    let managedObjectContext = (UIApplication.sharedApplication().delegate as AppDelegate).managedObjectContext
    
    @IBOutlet var tableView: UITableView!
    @IBOutlet var totalOutcome: UILabel!
    @IBOutlet var totalIncome: UILabel!
    @IBOutlet var total: UILabel!
    @IBOutlet var dateLabel: UILabel!
    
    var date = NSCalendar.currentCalendar().components(.CalendarUnitYear | .CalendarUnitMonth, fromDate: NSDate())
    var monthYear = [NSNumber]()
    var months = ["Januar","Februar","März","April","Mai","Juni","Juli",
        "August","September","Oktober","November", "Dezember"]
    var noEntries = "";
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Monat/ Jahr Anzeige
        if monthYear.isEmpty {
            monthYear = [date.month, date.year]
        }
        dateLabel.text = "\(months[Int(monthYear[0])-1]) \(monthYear[1])"
        
        //Delegates initialisieren
        tableView.dataSource = self
        tableView.delegate = self
        tableView.rowHeight = 44
        
        fetchedResultController = getFetchedResultController()
        fetchedResultController.delegate = self
        fetchedResultController.performFetch(nil)
        
        //Summen berechnen und anzeigen
        calcAndShowSums()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Fetch Result
    var fetchedResultController: NSFetchedResultsController = NSFetchedResultsController()
    
    func getFetchedResultController() -> NSFetchedResultsController {
        fetchedResultController = NSFetchedResultsController(fetchRequest: entryFetchRequest(), managedObjectContext: managedObjectContext!, sectionNameKeyPath: nil, cacheName: nil)
        return fetchedResultController
    }
    
    func entryFetchRequest() -> NSFetchRequest {
        let fetchRequest = NSFetchRequest(entityName: "Entry")
        let sortDescriptor = NSSortDescriptor(key: "date", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        //Fetch Request filtern
        //startDate: Anfang Monat
        //endDate: Ende Monat
        var startDate = createDates(year: Int(monthYear[1]),month: Int(monthYear[0]),day: 1)
        var endDate = NSDate()
        if (monthYear[0]==12) {
            endDate = createDates(year: Int(monthYear[1])+1,month: 1,day: 1)
        }
        else {
            endDate = createDates(year: Int(monthYear[1]),month: Int(monthYear[0])+1,day: 1)
        }
        let predicate1 = NSPredicate(format: "date >= %@", startDate)
        let predicate2 = NSPredicate(format: "date < %@", endDate)
        let predicate = NSCompoundPredicate(type: NSCompoundPredicateType.AndPredicateType, subpredicates: [predicate1!,predicate2!])
        fetchRequest.predicate = predicate
        
        return fetchRequest
    }
    
    // MARK: - Segue
    // benötigte Daten für nächsten ViewController bereitstellen
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "date" {
            var datePickerVC = segue.destinationViewController as DatePickerViewController
            datePickerVC.parentVC = self
            datePickerVC.monthYear = [monthYear[0],monthYear[1]]
        } else {
            var buchungsEintragVC = segue.destinationViewController as BuchungseintragViewController
            if segue.identifier == "income" {
                buchungsEintragVC.type = true   // Einnahme
            } else if segue.identifier == "outcome" {
                buchungsEintragVC.type = false  // Ausgabe
            } else if segue.identifier == "edit" {
                let cell = sender as UITableViewCell
                let indexPath = tableView.indexPathForCell(cell)
                let entry:Entry = fetchedResultController.objectAtIndexPath(indexPath!) as Entry
                buchungsEintragVC.category = entry.category
                buchungsEintragVC.entry = entry
            }
            
        }
    }
    
    // MARK: - Table View
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // Return the number of sections.
        return fetchedResultController.sections!.count
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return fetchedResultController.sections![section].numberOfObjects
    }
    
    //Daten aus Fetch Request anzeigen
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let entry = fetchedResultController.objectAtIndexPath(indexPath) as Entry
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath) as EntryCell
        
        cell.title.text = entry.title
        var df = NSDateFormatter()
        df.dateFormat = "dd.MM.yyyy"
        cell.detail.text = df.stringFromDate(entry.date)
        cell.value.text = String(format: "%.2f €", entry.value.floatValue)
        if entry.type == true{
            cell.value.textColor = UIColor(red: 53/255, green: 166/255, blue: 44/255, alpha: 1)
        } else {
            cell.value.textColor = UIColor(red: 215/255, green: 40/255, blue: 40/255, alpha: 1)
        }
        
        return cell
    }
    
    //Datensatz löschen
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        let managedObject:Entry = fetchedResultController.objectAtIndexPath(indexPath) as Entry
        var entry_items = managedObject.entry_items.allObjects as [NSManagedObject]
        for var i=0;i<managedObject.entry_items.count;i++
        {
            managedObjectContext?.deleteObject(entry_items[i])
        }
        
        managedObjectContext?.deleteObject(managedObject)
        managedObjectContext?.save(nil)
    }
    
    //Daten aktualisieren bei Änderung des Managed Object Context
    func controllerDidChangeContent(controller: NSFetchedResultsController!) {
        tableView.reloadData()
        calcAndShowSums()
    }
    
    //MARK: Class Functions
    //Berechnung und Anzeige der Summen
    func calcAndShowSums (){
        var red = UIColor(red: 215/255, green: 40/255, blue: 40/255, alpha: 1)
        var green = UIColor(red: 53/255, green: 166/255, blue: 44/255, alpha: 1)
        var dTotal = 0.0
        var dTotalIncome = 0.0
        var dTotalOutcome = 0.0
        for var i = 0;i<tableView.numberOfRowsInSection(0); i++ {
            var cellPath = NSIndexPath(forRow: i, inSection: 0)
            var cell = tableView.cellForRowAtIndexPath(cellPath) as EntryCell
            if (cell.value.textColor==red){
                dTotalOutcome += (cell.value.text! as NSString).doubleValue
            } else {
                dTotalIncome += (cell.value.text! as NSString).doubleValue
            }
        }
        dTotal = dTotalIncome - dTotalOutcome
        total.text = String(format: "= %.2f €",dTotal)
        totalIncome.text = String(format: "%.2f €",dTotalIncome)
        totalOutcome.text = String(format: "- %.2f €",dTotalOutcome)
    }
    
    //NSDate Object erstellen für Predicate
    func createDates(#year:Int, month:Int, day:Int) -> NSDate {
        var components = NSDateComponents()
        components.year = year
        components.month = month
        components.day = day
        
        var gregorian = NSCalendar(identifier:NSCalendarIdentifierGregorian)
        var date = gregorian!.dateFromComponents(components)
        return date!
    }
    
}
