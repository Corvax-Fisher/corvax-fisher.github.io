//
//  Subcategory.swift
//  Haushaltsbuch
//
//  Created by Medien on 19.12.14.
//  Copyright (c) 2014 THM. All rights reserved.
//

import Foundation
import CoreData

class Subcategory: NSManagedObject {

    @NSManaged var name: String
    @NSManaged var category: Category
    @NSManaged var item: NSSet

}
