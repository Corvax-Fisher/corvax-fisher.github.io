//
//  Entry_Items.swift
//  Haushaltsbuch
//
//  Created by Medien on 19.12.14.
//  Copyright (c) 2014 THM. All rights reserved.
//

import Foundation
import CoreData

class Entry_Items: NSManagedObject {

    @NSManaged var price: NSDecimalNumber
    @NSManaged var quantity: NSNumber
    @NSManaged var entry: Entry
    @NSManaged var item: NSManagedObject

}
