//
//  TaskDetailViewController.swift
//  TaskManager
//
//  Created by Medien on 24.11.14.
//  Copyright (c) 2014 THM. All rights reserved.
//

import UIKit
import CoreData

class TaskDetailViewController: UIViewController {

    let managedObjectContext = (UIApplication.sharedApplication().delegate as AppDelegate).managedObjectContext
    var task: Tasks? = nil

    @IBOutlet var txtDesc: UITextField!
    @IBOutlet var dateDesc: UIDatePicker!
    
    @IBAction func done(sender: AnyObject) {
        if task != nil {
            editTask()
        } else {
            createTask()
        }
        dismissViewController()
    }

    @IBAction func cancel(sender: AnyObject) {
        dismissViewController()
    }
    
    func dismissViewController() {
        navigationController?.popViewControllerAnimated(true)
    }
    
    func editTask() {
        task?.desc = txtDesc.text
        task?.date = dateDesc.date
        managedObjectContext?.save(nil)
    }
    
    func createTask() {
        let entityDescripition = NSEntityDescription.entityForName("Tasks", inManagedObjectContext: managedObjectContext!)
        let task = Tasks(entity: entityDescripition!, insertIntoManagedObjectContext: managedObjectContext?)
        task.desc = txtDesc.text
        task.date = dateDesc.date
        managedObjectContext?.save(nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let uwtask = task {
            txtDesc.text = uwtask.desc
            dateDesc.date = uwtask.date
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

}
