//
//  DatePickerViewController.swift
//  Haushaltsbuch
//
//  Created by Medien on 23.12.14.
//  Copyright (c) 2014 THM. All rights reserved.
//

import UIKit

class DatePickerViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    @IBOutlet var datePicker: UIPickerView!
    
    var date = NSCalendar.currentCalendar().components(.CalendarUnitYear | .CalendarUnitMonth, fromDate: NSDate())
    var monthYear = [NSNumber]()
    var months = ["Januar","Februar","März","April","Mai","Juni","Juli",
        "August","September","Oktober","November", "Dezember"]
    let numYears = 50
    
    var parentVC: UIViewController? = nil
    
    // Übergabe Monat/ Jahr an MainViewController
    @IBAction func done(sender: AnyObject) {
        var monthYear = [datePicker.selectedRowInComponent(0)+1,date.year-numYears+datePicker.selectedRowInComponent(1)+1]
        var months = (parentVC as MainViewController).months
        (parentVC as MainViewController).monthYear = monthYear
        (parentVC as MainViewController).dateLabel.text = "\(months[Int(monthYear[0])-1]) \(monthYear[1])"
        (parentVC as MainViewController).getFetchedResultController().performFetch(nil)
        (parentVC as MainViewController).tableView.reloadData()
        (parentVC as MainViewController).calcAndShowSums()
        
        dismissViewController()
    }
    
    func dismissViewController() {
        navigationController?.popViewControllerAnimated(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        datePicker.dataSource = self
        datePicker.delegate = self
    
        datePicker.selectRow(Int(monthYear[0])-1, inComponent: 0, animated: true)
        datePicker.selectRow(Int(monthYear[1])-date.year+numYears-1, inComponent: 1, animated: true)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Picker View
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if(component == 0) { return 12 }
        else { return numYears }
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) ->String! {
        if(component == 0) { return months[row] }
        else { return (date.year-numYears+row+1).description }
    }

}
