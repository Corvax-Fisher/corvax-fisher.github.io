//
//  TaskDetailViewController.swift
//  TaskManager
//
//  Created by Medien on 24.11.14.
//  Copyright (c) 2014 THM. All rights reserved.
//

import UIKit
import CoreData

class TaskDetailViewController: UIViewController {

    let managedObjectContext = (UIApplication.sharedApplication().delegate as AppDelegate).managedObjectContext
    
    //AUFGABE:
    //Typ von selectedTask in Tasks ändern nach Erstellung der NSManagedObject Subklasse
    var selectedTask: NSManagedObject? = nil

    @IBOutlet var txtDesc: UITextField!
    
    @IBAction func done(sender: AnyObject) {
        if selectedTask != nil {
            editTask()
        } else {
            createTask()
        }
        dismissViewController()
    }

    @IBAction func cancel(sender: AnyObject) {
        dismissViewController()
    }
    
    func dismissViewController() {
        navigationController?.popViewControllerAnimated(true)
    }
    
    // AUFGABE: Änderungen des ausgewählten Tasks speichern
    func editTask() {

        
    }
    
    // AUFGABE: Task abspeichern (create)
    func createTask() {

        
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // AUFGABE: Beschreibung von ausgewähltem Task in txtDesc anzeigen

        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

}
