//
//  Item.swift
//  Haushaltsbuch
//
//  Created by Medien on 19.12.14.
//  Copyright (c) 2014 THM. All rights reserved.
//

import Foundation
import CoreData

class Item: NSManagedObject {

    @NSManaged var name: String
    @NSManaged var entry_items: NSSet
    @NSManaged var subcategory: NSManagedObject

}
