//
//  EntryCell.swift
//  Haushaltsbuch
//
//  Created by Medien on 22.12.14.
//  Copyright (c) 2014 THM. All rights reserved.
//

import Foundation
import UIKit

// Custom Cell
class EntryCell: UITableViewCell {
    
    @IBOutlet var title: UILabel!
    
    @IBOutlet var detail: UILabel!
    
    @IBOutlet var value: UILabel!
    
    
}
