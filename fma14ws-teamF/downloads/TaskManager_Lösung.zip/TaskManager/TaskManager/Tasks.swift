//
//  Tasks.swift
//  TaskManager
//
//  Created by Medien on 24.11.14.
//  Copyright (c) 2014 THM. All rights reserved.
//

import Foundation
import CoreData

class Tasks: NSManagedObject {

    @NSManaged var desc: String
    @NSManaged var date: NSDate

}
