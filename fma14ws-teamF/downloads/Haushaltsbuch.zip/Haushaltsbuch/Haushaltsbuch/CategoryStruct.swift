//
//  CategoryStruct.swift
//  Haushaltsbuch
//
//  Created by Medien on 22.12.14.
//  Copyright (c) 2014 THM. All rights reserved.
//

struct CategoryStruct {
    var name :String
    var subcategories: [String]
}
