//
//  BuchungseintragViewController.swift
//  Haushaltsbuch
//
//  Created by Medien on 08.12.14.
//  Copyright (c) 2014 THM. All rights reserved.
//

import UIKit
import CoreData

class BuchungseintragViewController: UIViewController,UIAlertViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIPopoverControllerDelegate, UIPickerViewDataSource, UIPickerViewDelegate {
    
    let managedObjectContext = (UIApplication.sharedApplication().delegate as AppDelegate).managedObjectContext
    
    @IBOutlet var entryType: UILabel!
    @IBOutlet var entryDate: UITextField!
    @IBOutlet var entryValue: UITextField!
    @IBOutlet var entryTitle: UITextField!
    @IBOutlet var categories: UIPickerView!
    @IBOutlet var imageView: UIImageView!
    @IBOutlet var chooseButton: UIButton!
    
    var imagePicker = UIImagePickerController()
    var popover:UIPopoverController?=nil
    
    var entry: Entry? = nil
    var newEntry: Bool = true
    var category: Category? = nil
    let categoryStructs = [CategoryStruct(name: "Lebensmittel",subcategories: ["Obst","Gemüse"]),
        CategoryStruct(name: "Elekronik",subcategories: ["Kabel","Buchsen","Computer"]),
        CategoryStruct(name: "Kleidung",subcategories: ["Hemden","Hosen","Accessoires","Taschen","Jacken"]),
        CategoryStruct(name: "Möbel",subcategories: ["Schlafzimmer","Wohnzimmer","Kinderzimmer","Küche"])
    ]
    var type = true

    func dismissViewController() {
        navigationController?.popViewControllerAnimated(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        categories.dataSource = self
        categories.delegate = self
        
        imagePicker.delegate = self
        
        //Anzeige des Buchungstyps
        if type {
            entryType.text = "Einnahme"
        } else {
            entryType.text = "Ausgabe"
        }
        
        //Anzeige existierender Buchung
        loadEntry()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Save
    // Buchungseintrag speichern
    // editEntry - Überschreibung des vorhandenen Datensatzes
    // createEntry - Erstellung eines neuen Datensatzes
    @IBAction func save(sender: AnyObject) {
        if textFieldValuesValid() {
            if newEntry == false {
                editEntry()
            } else {
                createEntry()
            }
            dismissViewController()
        } else {
            var alert = UIAlertController(title: "Ungültige Werte", message: "Buchung kann nicht gespeichert werden.", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
        }
    }
    
    // MARK: - Cancel
    @IBAction func cancel(sender: AnyObject) {
        dismissViewController()
        //Wiederherstellen auf den letzten Stand im Persistent Store
        managedObjectContext!.rollback()
    }
    
    // MARK: - Segue
    // benötigte Daten für nächsten ViewController bereitstellen
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        var artikelEintragVC = segue.destinationViewController as ArtikeleintragViewController
        if segue.identifier == "edit" {
            artikelEintragVC.entry = entry
            artikelEintragVC.selectedCategory = categoryStructs[categories.selectedRowInComponent(0)]
            artikelEintragVC.parentVC = self
        }
    }
    
    // MARK: - Class Functions
    // speichern in managedObjectContext (update)
    func editEntry() {
        entry?.title = entryTitle.text
        entry?.value = NSDecimalNumber (string: entryValue.text)
        
        var df = NSDateFormatter()
        df.dateFormat = "dd.MM.yyyy"
        entry?.date = df.dateFromString(entryDate.text)!
        
        category?.name = categoryStructs[categories.selectedRowInComponent(0)].name
        entry?.category = category!
        
        entry?.image = UIImageJPEGRepresentation(imageView.image, 1);
        
        var e:NSError?
        if !managedObjectContext!.save(&e) {
            println("insert error (edit): \(e!.localizedDescription)")
            abort()
        }
    }
    
    // MARK: - Class Functions
    // speichern in managedObjectContext (create)
    func createEntry() {
        if entry == nil {
            entry = NSEntityDescription.insertNewObjectForEntityForName("Entry", inManagedObjectContext: managedObjectContext!) as? Entry
        }
        let category: Category = NSEntityDescription.insertNewObjectForEntityForName("Category", inManagedObjectContext: managedObjectContext!) as Category
        
        entry!.type = type
        entry!.title = entryTitle.text
        entry!.value = NSDecimalNumber (string: entryValue.text)
        
        var df = NSDateFormatter()
        df.dateFormat = "dd.MM.yyyy"
        entry!.date = df.dateFromString(entryDate.text)!
        
        category.name = categoryStructs[categories.selectedRowInComponent(0)].name
        entry!.category = category
        
        entry!.image = UIImageJPEGRepresentation(imageView.image, 1);
        
        var e:NSError?
        if !managedObjectContext!.save(&e) {
            println("insert error (create): \(e!.localizedDescription)")
            abort()
        }
    }
    
    // Daten aus Entry und Category werden in den View geladen
    func loadEntry(){
        if let uwentry = entry {
            newEntry = false
            
            //Anzeige des Buchungstyps
            if uwentry.type.boolValue {
                entryType.text = "Einnahme"
            } else {
                entryType.text = "Ausgabe"
            }
            
            entryValue.text = uwentry.value.description
            entryTitle.text = uwentry.title
            var df = NSDateFormatter()
            df.dateFormat = "dd.MM.yyyy"
            entryDate.text = df.stringFromDate(uwentry.date)
            
            imageView.image = UIImage(data: uwentry.image)
            
        }
        if let uwcategory = category {
            var row: Int = -1
            for var i=0 ;i<categoryStructs.count;i++
            {
                if categoryStructs[i].name == uwcategory.name {
                    row = i
                }
            }
            if row != -1 {
                categories.selectRow(row, inComponent: 0, animated: true)
            } else {
                println("category not found")
            }
            
        }
    }
    
    // MARK: - Picker View
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return categoryStructs.count
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) ->String! {
        return categoryStructs[row].name
    }
    
    // MARK: - Image Picker
    @IBAction func btnImagePickerClicked(sender: AnyObject) {
        
        var alert:UIAlertController=UIAlertController(title: "Choose Image", message: nil, preferredStyle: UIAlertControllerStyle.ActionSheet)
        
        var cameraAction = UIAlertAction(title: "Camera", style: UIAlertActionStyle.Default)
            {
                UIAlertAction in
                self.openCamera()
                
        }
        var galleryAction = UIAlertAction(title: "Gallery", style: UIAlertActionStyle.Default)
            {
                UIAlertAction in
                self.openGallery()
        }
        var cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel)
            {
                UIAlertAction in
                
        }
        // Add the actions
        alert.addAction(cameraAction)
        alert.addAction(galleryAction)
        alert.addAction(cancelAction)
        // Present the actionsheet
        if UIDevice.currentDevice().userInterfaceIdiom == .Phone
        {
            self.presentViewController(alert, animated: true, completion: nil)
        }
        else
        {
            popover=UIPopoverController(contentViewController: alert)
            popover!.presentPopoverFromRect(chooseButton.frame, inView: self.view, permittedArrowDirections: UIPopoverArrowDirection.Any, animated: true)
        }
    }
    
    // MARK: - Camera and Gallery
    func openCamera()
    {
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera))
        {
            imagePicker.sourceType = UIImagePickerControllerSourceType.Camera
            self .presentViewController(imagePicker, animated: true, completion: nil)
        }
        else
        {
            openGallery()
        }
    }
    func openGallery()
    {
        imagePicker.sourceType = UIImagePickerControllerSourceType.PhotoLibrary
        if UIDevice.currentDevice().userInterfaceIdiom == .Phone
        {
            self.presentViewController(imagePicker, animated: true, completion: nil)
        }
        else
        {
            popover=UIPopoverController(contentViewController: imagePicker)
            popover!.presentPopoverFromRect(chooseButton.frame, inView: self.view, permittedArrowDirections: UIPopoverArrowDirection.Any, animated: true)
        }
    }
    
    func imagePickerController(imagePicker: UIImagePickerController!, didFinishPickingMediaWithInfo info: NSDictionary!) {
        self.dismissViewControllerAnimated(true, completion:nil)
        let tempImage:UIImage = info[UIImagePickerControllerOriginalImage] as UIImage
        self.imageView.image = tempImage
    }
    
    func textFieldValuesValid() -> Bool {
        var isValid = !entryTitle.text.isEmpty
        isValid = isValid && NSDecimalNumber(string: entryValue.text).description != "NaN"
        var df = NSDateFormatter()
        df.dateFormat = "dd.MM.yyyy"
        let date = df.dateFromString(entryDate.text)
        isValid = isValid && date != nil
        println(date)
        return isValid
    }

}
