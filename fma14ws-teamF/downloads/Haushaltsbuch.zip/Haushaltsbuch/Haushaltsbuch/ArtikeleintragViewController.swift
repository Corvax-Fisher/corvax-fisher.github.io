//
//  ArtikeleintragViewController.swift
//  Haushaltsbuch
//
//  Created by Medien on 08.12.14.
//  Copyright (c) 2014 THM. All rights reserved.
//

import UIKit
import CoreData

class ArtikeleintragViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate, UITableViewDelegate, UITableViewDataSource {

    let managedObjectContext = (UIApplication.sharedApplication().delegate as AppDelegate).managedObjectContext    
    
    @IBOutlet var tableView: UITableView!
    @IBOutlet var artikelName: UITextField!
    @IBOutlet var artikelPreis: UITextField!
    @IBOutlet var quantityPicker: UIPickerView!
    @IBOutlet var subcategoryPicker: UIPickerView!
    
    var parentVC: UIViewController? = nil
    var entry: Entry? = nil
    var selectedCategory = CategoryStruct(name: "",subcategories: [])
    
    var nCenter = NSNotificationCenter()
    
    @IBAction func save(sender: AnyObject) {
        
        //Betrag an hinzugefügte Artikel anpassen
        updateEntryValue()
        
        dismissViewController()
    }
    
    @IBAction func cancel(sender: AnyObject) {
        //Wiederherstellen auf den letzten Stand im Persistent Store
        managedObjectContext!.rollback()
        entry = nil
        (parentVC as BuchungseintragViewController).entry = nil
        
        dismissViewController()
        tableView.reloadData()
    }
    
    //Hinzufügen eines Artikels (ohne Speichern)
    @IBAction func addItem() {
        if textFieldValuesValid() {
            if entry == nil {
                entry = NSEntityDescription.insertNewObjectForEntityForName("Entry", inManagedObjectContext: managedObjectContext!) as? Entry
                (parentVC as BuchungseintragViewController).entry = entry
            }
            let item = NSEntityDescription.insertNewObjectForEntityForName("Item", inManagedObjectContext: managedObjectContext!) as Item
            let entry_items = NSEntityDescription.insertNewObjectForEntityForName("Entry_Items", inManagedObjectContext: managedObjectContext!) as Entry_Items
            let subcategory: Subcategory = NSEntityDescription.insertNewObjectForEntityForName("Subcategory", inManagedObjectContext: managedObjectContext!) as Subcategory
            
            subcategory.name = selectedCategory.subcategories[subcategoryPicker.selectedRowInComponent(0)]
            
            item.subcategory = subcategory
            item.name = artikelName.text
            
            entry_items.item = item
            entry_items.entry = entry!
            entry_items.price = NSDecimalNumber(string: artikelPreis.text)
            entry_items.quantity = quantityPicker.selectedRowInComponent(0)+1
            
            tableView.reloadData()
        } else {
            var alert = UIAlertController(title: "Ungültige Werte", message: "Artikel kann nicht hinzugefügt werden.", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
        }

    }
    
    func dismissViewController() {
        navigationController?.popViewControllerAnimated(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        quantityPicker.delegate = self
        quantityPicker.dataSource = self
        
        subcategoryPicker.delegate = self
        subcategoryPicker.dataSource = self
        
        tableView.dataSource = self
        tableView.delegate = self
        tableView.rowHeight = 44

        NSNotificationCenter.defaultCenter().addObserver(self, selector: "handleChangeNotification:", name: NSManagedObjectContextObjectsDidChangeNotification, object: managedObjectContext)

    }
    
    func handleChangeNotification(n: NSNotification) {
        tableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table View
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // Return the number of sections.
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        var ret = entry?.entry_items.count
        if ret != nil {return ret! }
        else {return 0 }
    }
    
    //Daten aus Managed Object Context anzeigen
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath) as EntryCell
        let selectedEntryItem = entry?.entry_items.allObjects[indexPath.indexAtPosition(1)] as Entry_Items
        
        cell.title.text = (selectedEntryItem.item as Item).name
        cell.detail.text = "Stückpreis: \(selectedEntryItem.price) €, Anzahl: \(selectedEntryItem.quantity)"
        var total = selectedEntryItem.price.floatValue*selectedEntryItem.quantity.floatValue
        
        cell.value.text = String(format: "%.2f €", total)
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        //let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath) as EntryCell
        let selectedEntryItem = entry?.entry_items.allObjects[indexPath.indexAtPosition(1)] as Entry_Items

        artikelName.text = selectedEntryItem.item.valueForKey("name") as String
        artikelPreis.text = (selectedEntryItem.valueForKey("price") as NSDecimalNumber).description
        quantityPicker.selectRow((selectedEntryItem.valueForKey("quantity") as NSNumber).integerValue-1, inComponent: 0, animated: true)
        let selectedSubcategory = ((selectedEntryItem.item as Item).subcategory as Subcategory).name
        var selectedSubcategoryRow = 0
        for var i = 0; i < selectedCategory.subcategories.count;i++ {
            if selectedCategory.subcategories[i] == selectedSubcategory { selectedSubcategoryRow = i }
        }
        subcategoryPicker.selectRow(selectedSubcategoryRow, inComponent: 0, animated: true)
    }
    
    // Datensatz löschen
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        //println(indexPath.indexAtPosition(1))
        //(entry?.entry_items as NSMutableSet).removeObject(entry!.entry_items.allObjects[indexPath.indexAtPosition(1)])
        managedObjectContext?.deleteObject(entry?.entry_items.allObjects[indexPath.indexAtPosition(1)] as Entry_Items)
        //self.tableView.reloadData()
    }
    
    // MARK: - Picker View
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView==quantityPicker { return 99 }
        else { return selectedCategory.subcategories.count }
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) ->String! {
        if pickerView==quantityPicker {
            return "\(row+1)"
        } else {
            return selectedCategory.subcategories[row]
        }
    }
    
    // MARK: - Class Functions
    func updateEntryValue(){
        if entry?.entry_items.count > 0 {
            entry?.value = 0
            
            for var i=0 ; i < entry?.entry_items.count; i++ {
                entry?.value = (entry?.value.decimalNumberByAdding((entry?.entry_items.allObjects[i] as Entry_Items).price.decimalNumberByMultiplyingBy(NSDecimalNumber(integer: (entry?.entry_items.allObjects[i] as Entry_Items).quantity.integerValue))))!
            }
            (parentVC as BuchungseintragViewController).entryValue.text = entry?.value.description
        }
    }
    
    func textFieldValuesValid() -> Bool {
        var isValid = !artikelName.text.isEmpty
        isValid = isValid && NSDecimalNumber(string: artikelPreis.text).description != "NaN"
        return isValid
    }

}
