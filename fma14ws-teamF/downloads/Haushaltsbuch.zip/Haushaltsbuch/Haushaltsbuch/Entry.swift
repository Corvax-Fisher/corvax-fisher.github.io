//
//  Entry.swift
//  Haushaltsbuch
//
//  Created by Medien on 19.12.14.
//  Copyright (c) 2014 THM. All rights reserved.
//

import Foundation
import CoreData

class Entry: NSManagedObject {

    @NSManaged var date: NSDate
    @NSManaged var image: NSData
    @NSManaged var title: String
    @NSManaged var type: NSNumber
    @NSManaged var value: NSDecimalNumber
    @NSManaged var category: Category
    @NSManaged var entry_items: NSSet

}
